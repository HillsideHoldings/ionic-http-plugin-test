#import <Foundation/Foundation.h>
#import <Cordova/CDVPlugin.h>
#import "DownloadManager.h"

enum CdvHttpDownloadError {
    FILE_NOT_FOUND_ERR = 1,
    INVALID_URL_ERR = 2,
    DOWNLOAD_ERR = 3,
    DOWNLOAD_ABORTED = 4,
    NOT_MODIFIED = 5
};
typedef int CdvHttpDownloadError;

//@class CordovaHttpPlugin;
//
//@protocol CordovaHttpPluginDelegate <NSObject>
//
//@optional
//// Called to notify delegate that the download completed.
//- (void)downloadDidFinishLoading:(CordovaHttpPlugin *)download;
//// Called to notify delegate that the download failed.
//- (void)downloadDidFail:(CordovaHttpPlugin *)download;
//// Called to notify delegate that the download is receiving data.
//- (void)downloadDidReceiveData:(CordovaHttpPlugin *)download;
//
//@end

@interface CordovaHttpPlugin : CDVPlugin

@property (strong, nonatomic) DownloadManager *downloadManager;

- (struct JsonHttpResponse) httpRequest:(NSString *) endpoint;

- (void)downloadFile:(CDVInvokedUrlCommand*)command;
- (void)uploadFile:(CDVInvokedUrlCommand*)command;
- (void)abortDownload:(CDVInvokedUrlCommand*)command;
- (void)enableSSLPinning:(CDVInvokedUrlCommand*)command;
- (void)acceptAllCerts:(CDVInvokedUrlCommand*)command;
- (void)validateDomainName:(CDVInvokedUrlCommand*)command;
- (void)post:(CDVInvokedUrlCommand*)command;
- (void)get:(CDVInvokedUrlCommand*)command;

@end