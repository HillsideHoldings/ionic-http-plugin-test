//  Download.m
//
//  Created by Yuri Medvedenko on 11/20/16.

#import "Download.h"

@interface Download () <NSURLConnectionDataDelegate, NSURLConnectionDelegate>

@property (strong, nonatomic) NSOutputStream *downloadStream;
@property (strong, nonatomic) NSURLConnection *connection;
@property (strong, nonatomic) NSString *tempFilename;

@end

@implementation Download

#pragma mark - Public methods

- (instancetype)initWithFilename:(NSString *)filename URL:(NSURL *)url RANGE:(NSString *)requestRange delegate:(id<DownloadDelegate>)delegate
{
    self = [super init];
    
    if (self) {
        _filename = [filename copy];
        _url = [url copy];
        _requestRange = [requestRange copy];
        _delegate = delegate;
    }
    
    return self;
}

- (void)start
{
    // initialize progress variables
    
    self.downloading = YES;
    self.expectedContentLength = -1;
    self.progressContentLength = 0;
    
    // create the download file stream (so we can write the file as we download it)
    
    self.tempFilename = [self pathForTemporaryFileWithPrefix:@"downloads"];
    self.downloadStream = [NSOutputStream outputStreamToFileAtPath:self.tempFilename append:NO];
    if (!self.downloadStream) {
        self.error = [NSError errorWithDomain:[NSBundle mainBundle].bundleIdentifier
                                         code:-1
                                     userInfo:@{@"message": @"Unable to create NSOutputStream", @"function" : @(__FUNCTION__), @"path" : self.tempFilename}];
        
        [self cleanupConnectionSuccessful:NO];
        return;
    }
    [self.downloadStream open];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:self.url
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:30.0];
    [request setValue:self.requestRange forHTTPHeaderField:@"Range"];
    if (!request) {
        self.error = [NSError errorWithDomain:[NSBundle mainBundle].bundleIdentifier
                                         code:-1
                                     userInfo:@{@"message": @"Unable to create URL", @"function": @(__FUNCTION__), @"URL" : self.url}];
        
        [self cleanupConnectionSuccessful:NO];
        return;
    }
    
    self.connection = [[NSURLConnection alloc] initWithRequest:request delegate:self startImmediately:NO];
    [self.connection scheduleInRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    [self.connection start];
    
    if (!self.connection) {
        self.error = [NSError errorWithDomain:[NSBundle mainBundle].bundleIdentifier
                                         code:-1
                                     userInfo:@{@"message": @"Unable to create NSURLConnection", @"function" : @(__FUNCTION__), @"NSURLRequest" : request}];
        
        [self cleanupConnectionSuccessful:NO];
    }
}

- (void)cancel
{
    [self cleanupConnectionSuccessful:NO];
}

#pragma mark - Private methods

- (BOOL)createFolderForPath:(NSString *)filePath
{
    NSError *error;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *folder = [filePath stringByDeletingLastPathComponent];
    BOOL isDirectory;
    
    if (![fileManager fileExistsAtPath:folder isDirectory:&isDirectory]) {
        // if folder doesn't exist, try to create it
        
        [fileManager createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:&error];
        
        // if fail, report error

        if (self.error) {
            self.error = error;
            return FALSE;
        }
        
        // directory successfully created
        
        return TRUE;
    } else if (!isDirectory) {
        self.error = [NSError errorWithDomain:[NSBundle mainBundle].bundleIdentifier
                                         code:-1
                                     userInfo:@{@"message": @"Unable to create directory; file exists by that name", @"function" : @(__FUNCTION__), @"folder": folder}];
        return FALSE;
    }
    
    // directory already existed
    
    return TRUE;
}

- (void)cleanupConnectionSuccessful:(BOOL)success
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;

    // clean up connection and download steam
    
    if (self.connection != nil) {
        if (!success) {
            [self.connection cancel];
        }
        self.connection = nil;
    }
    if (self.downloadStream != nil) {
        [self.downloadStream close];
        self.downloadStream = nil;
    }
    
    self.downloading = NO;
    
    // if successful, move file and clean up, otherwise just cleanup
    
    if (success) {
        if (![self createFolderForPath:self.filename]) {
            [self.delegate downloadDidFail:self];
            return;
        }

        if ([fileManager fileExistsAtPath:self.filename]) {
            [fileManager removeItemAtPath:self.filename error:&error];
            if (error) {
                self.error = error;
                [self.delegate downloadDidFail:self];
                return;
            }
        }
        
        [fileManager copyItemAtPath:self.tempFilename toPath:self.filename error:&error];
        if (error) {
            self.error = error;
            [self.delegate downloadDidFail:self];
            return;
        }

        [fileManager removeItemAtPath:self.tempFilename error:&error];
        if (error) {
            self.error = error;
            [self.delegate downloadDidFail:self];
            return;
        }

        [self.delegate downloadDidFinishLoading:self];
    }
    else
    {
        if (self.tempFilename)
            if ([fileManager fileExistsAtPath:self.tempFilename]) {
//                [fileManager copyItemAtPath:self.tempFilename toPath:self.filename error:&error];
                [fileManager removeItemAtPath:self.tempFilename error:&error];
                NSLog(@"tempFile is being copied to filePath...");
            }
        [self.delegate downloadDidFail:self];
    }
}

- (NSString *)pathForTemporaryFileWithPrefix:(NSString *)prefix
{
    NSString *  result;
    CFUUIDRef   uuid;
    CFStringRef uuidStr;
    
    uuid = CFUUIDCreate(NULL);
    assert(uuid != NULL);
    
    uuidStr = CFUUIDCreateString(NULL, uuid);
    assert(uuidStr != NULL);
    
    result = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", prefix, uuidStr]];
    assert(result != nil);
    
    CFRelease(uuidStr);
    CFRelease(uuid);
    
    return result;
}

#pragma mark - NSURLConnectionDataDelegate methods

- (void)connection:(NSURLConnection*)connection didReceiveResponse:(NSURLResponse *)response
{
    if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
        NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
        
        if (statusCode == 200) {
            self.expectedContentLength = [response expectedContentLength];
        } else if (statusCode >= 400) {
            self.error = [NSError errorWithDomain:[NSBundle mainBundle].bundleIdentifier
                                             code:statusCode
                                         userInfo:@{
                                                      @"message" : @"bad HTTP response status code",
                                                      @"function": @(__FUNCTION__),
                                                      @"NSHTTPURLResponse" : response
                                                  }];
            [self cleanupConnectionSuccessful:NO];
        }
    } else {
        self.expectedContentLength = -1;
    }
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    NSInteger       dataLength = [data length];
    const uint8_t * dataBytes  = [data bytes];
    NSInteger       bytesWritten;
    NSInteger       bytesWrittenSoFar;
    
    //try to access that local file for writing to it...
    NSFileHandle *hFile = [NSFileHandle fileHandleForWritingAtPath:self.filename];
    //did we succeed in opening the existing file?
    if (!hFile)
    {   //nope->create that file!
        [[NSFileManager defaultManager] createFileAtPath:self.filename contents:nil attributes:nil];
        //try to open it again...
        hFile = [NSFileHandle fileHandleForWritingAtPath:self.filename];
    }
    //did we finally get an accessable file?
    if (!hFile)
    {   //nope->bomb out!
        NSLog(@"could not write to file %@", self.filename);
        return;
    }
    //we never know - hence we better catch possible exceptions!
    @try
    {
        //seek to the end of the file
        [hFile seekToEndOfFile];
        //finally write our data to it
        [hFile writeData:data];
        [hFile synchronizeFile];
    }
    @catch (NSException * e)
    {
        NSLog(@"exception when writing to file %@", self.filename);
    }
    
    bytesWrittenSoFar = 0;
    do {
        bytesWritten = [self.downloadStream write:&dataBytes[bytesWrittenSoFar] maxLength:dataLength - bytesWrittenSoFar];
        assert(bytesWritten != 0);
        NSLog(@"File content is written to file in filePath");
        if (bytesWritten == -1) {
            [self cleanupConnectionSuccessful:NO];
            break;
        } else {
            bytesWrittenSoFar += bytesWritten;
        }
    } while (bytesWrittenSoFar != dataLength);
    
    self.progressContentLength += dataLength;
    
    [hFile closeFile];
    
    if ([self.delegate respondsToSelector:@selector(downloadDidReceiveData:)])
        [self.delegate downloadDidReceiveData:self];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    [self cleanupConnectionSuccessful:YES];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error
{
    self.error = error;
    self.downloading = FALSE;
    [self cleanupConnectionSuccessful:NO];
}

@end
